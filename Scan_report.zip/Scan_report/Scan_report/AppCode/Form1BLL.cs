﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using GeneralFunction;


public class Form1BLL
{
    public static int INTID = 0;

    //-------------------For Save-Insert-Submit-----------------

    public static void InsertFormDataBLL(TextBox txtEpmid, TextBox txtName, DateTimePicker dtpDob, TextBox txtSalary, ref string strMsg)
    {
        DLL.InsertFormDataDLL(txtEpmid, txtName, dtpDob, txtSalary, ref strMsg);
    }

    //-------------------For Update-----------------

    public static void UpdateFormDataBLL(TextBox txtEpmid, TextBox txtName, DateTimePicker dtpDob, TextBox txtSalary, ref string strMsg)
    {
        DLL.UpdateFormDataDLL(txtEpmid, txtName, dtpDob, txtSalary, ref strMsg);
    }

    //-------------------For Data Fetch By SQL-----------------
    public static void FetchData(DataGridView dgvGradeMaster)
    {
        DataTable tmpPurMaster = BLL.obj.opnTable("ProcDisplayEmp_DetailData");
        BindTitleGridToEdit(tmpPurMaster, dgvGradeMaster);
    }

    //-------------------For Grid Box-----------------
    public static void BindTitleGridToEdit(DataTable tbl, DataGridView dgv)
    {
        BLL.obj.FillGrid(tbl, "EmpId,Name,DOB,Salary", dgv, "EmpId,Name,DOB,Salary", Tables.Editable.False);
        BLL.obj.GridColFormat(dgv, 0, 100, "L", "");
        BLL.obj.GridColFormat(dgv, 1, 232, "L", "");
        BLL.obj.GridColFormat(dgv, 2, 120, "L", "");
        BLL.obj.GridColFormat(dgv, 3, 100, "L", "");

    }
//-------------------For Error Provider-----------------
    public static bool CheckBlank(TextBox txtEpmid, TextBox txtName, DateTimePicker dtpDob, TextBox txtSalary, ErrorProvider err)
    {
        if (txtEpmid.Text != "")
        {
            err.Clear();
            BLL.isVallid = true;
        }
        else
        {
            err.SetError(txtEpmid, "Enter Emp. Id...!!!");
            BLL.isVallid = false;
            return false;
        }
   
        
        if (txtName.Text != "")
        {
            err.Clear();
            BLL.isVallid = true;
        }
        else
        {
            err.SetError(txtName, "Enter Name...!!!");
            BLL.isVallid = false;
            return false;
        }
        if (dtpDob.Text != "")
        {
            err.Clear();
            BLL.isVallid = true;
        }
        else
        {
            err.SetError(dtpDob, "Enter Date of Birth...!!!");
            BLL.isVallid = false;
            return false;
        }
        //if ((cmbClass.Text != "") && (cmbClass.Text != "Select"))
        //{
        //    err.Clear();
        //    BLL.isVallid = true;
        //}
        //else
        //{
        //    err.SetError(cmbClass, "Select Class...!!!");
        //    BLL.isVallid = false;
        //    return false;
        //}

        //if (txtAddress.Text != "")
        //{
        //    err.Clear();
        //    BLL.isVallid = true;
        //}
        //else
        //{
        //    err.SetError(txtAddress, "Enter Address..!!!");
        //    BLL.isVallid = false;
        //    return false;
        //}
        //if (numMob.Text != "")
        //{
        //    err.Clear();
        //    BLL.isVallid = true;
        //}
        //else
        //{
        //    err.SetError(numMob, "Enter Mobile..!!!");
        //    BLL.isVallid = false;
        //    return false;
        //}
        if (txtSalary.Text != "")
        {
            err.Clear();
            BLL.isVallid = true;
        }
        else
        {
            err.SetError(txtSalary, "Enter Salary...!!!");
            BLL.isVallid = false;
            return false;
        }

        return BLL.isVallid;
    }

    //-------------------For Data Fetch in ComboBox-----------------
    public static void DisplayDataFromIDBasic(ComboBox cmbState, DataGridView dgvGradeMaster)
    {
        DataTable tmpPurMaster = BLL.obj.opnTable("ProcDisplaycmbBid" + cmbState.SelectedValue.ToString() + "'");
        BindTitleGridToEdit(tmpPurMaster, dgvGradeMaster);
    }
}

