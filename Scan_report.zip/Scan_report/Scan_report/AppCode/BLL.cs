﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;
using System.Text.RegularExpressions;
using GeneralFunction;

public class BLL
{
    public static Form frmObj = new Form();
    //---------For Login Information-------------------------------
    public static string CompId = "0";
    public static string CWHId = "0";
    public static string BrnId = "0";
    public static string StrINID = "0";
    public static string BranchID = string.Empty;
    public static string BranchName = string.Empty;
    public static string RoleName = string.Empty;
    public static string Designation = string.Empty;
    public static string RoleID = "0";
    public static string UserId = "0";//UserInfoID
    public static string EmpID = string.Empty; //UserLoginID
    public static string EmpName = string.Empty;//User Name
    public static string DeptID = string.Empty;
    public static string DTBCFAID = string.Empty;
    public static int FaYear = 0;
    public static string FaYearText = "";
    public static int intCount = 0;
    public static string CountryID = string.Empty;//Company County ID
    public static string StateID = string.Empty;//Company State ID
    public static string CityID = string.Empty;//Company City ID
    public static string strDomain = string.Empty;// Domain  Name
    public static string strSuper = string.Empty;//Super Admin
    public static string strCWHCode = string.Empty;//CWH Code
    public static string strDomainFormClose = string.Empty;// Domain Form Close means not login
        
    //-----------------------------
    public static DataTable tblSource = new DataTable();
    public static DataTable tblSourceCFAPacking = new DataTable();
    public static DataTable tblSourcePartyPacking = new DataTable();
    public static DataTable tblSourceSpecimenPartyPacking = new DataTable();
    public static DataTable tblGoToTransport = new DataTable();
    public static Tables obj = new Tables();
    public static DataSet dset = new DataSet("dset");
    public static string strBtnText = string.Empty;//Use for Save/
    public static string strSave = string.Empty;//Use for Save/
    public static string strDoubleClickID = string.Empty;//Use to get key value 
    public static string strFormText = string.Empty;//Use to get Form Text to use Country,State,City forms 
    public static bool isVallid = false;
    public static bool Vallid = false;
    public static string strCompanyName = "Arihant Publication (I) Limited";
    public static string strMsg = string.Empty;
    public static string strbtnImport = string.Empty;
    public static string strPath = Application.StartupPath + "\\89r47yqy.bmp";
    public static byte[] picture = null;
    public static byte[] LetterHeadPicture = null;
    //----------For Primary key-------------
    public static Random rndNumber = new Random();
    public static string strKeyValue = string.Empty;// This value contains  rndNumber+1+UserID 
    //-----------------------
    //-------------Use in Reports-------------------
    public static string strCompName = string.Empty;
    public static string strCompanyAddress = string.Empty;
    public static string strCompEmail = string.Empty;
    public static string strCompanyTinNo = string.Empty;
    public static string strCompanyPhone = string.Empty;
    public static string strCompanyWebsite = string.Empty;
    public static string strCompanyFax = string.Empty;
    public static string strCompanyIntroduction = string.Empty;
    public static string ExportDataToExcel = string.Empty;
}

