﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using GeneralFunction;



public class DLL
{
    public static SqlTransaction Trn = null;
    public static string strPNo1 = "";
    public static string strMRID1 = "";

    public static Tables Obj = new Tables();

    // ---------------------For Company Setting-------------
    //-------------------For Tbl_UserInformation-----------------

    //-----------------Submit Data into SQL Database---------------
    public static void InsertFormDataDLL(TextBox txtEpmid, TextBox txtName, DateTimePicker dtpDob, TextBox txtSalary, ref string strMsg)
    {
        try
        {
            Obj.SqlConn = new SqlConnection(Obj.ConnectionString());
            Obj.SqlCmd = new SqlCommand("ProcInsert_Emp_Detail", Obj.SqlConn);
            Obj.SqlCmd.CommandType = CommandType.StoredProcedure;

            Obj.SqlCmd.Parameters.Add("@EmpId", SqlDbType.NVarChar, 100).Value = txtEpmid.Text.Trim();
            Obj.SqlCmd.Parameters.Add("@Name", SqlDbType.NVarChar, 100).Value = txtName.Text.Trim();
            Obj.SqlCmd.Parameters.Add("@DOB", SqlDbType.SmallDateTime).Value = dtpDob.Value.Date;
            Obj.SqlCmd.Parameters.Add("@Salary", SqlDbType.NVarChar, 100).Value = txtSalary.Text.Trim();

            Obj.SqlCmd.Parameters.Add("@strMsg", SqlDbType.NVarChar, 100).Direction = ParameterDirection.Output;
            Obj.SqlConn.Open();
            Obj.SqlCmd.ExecuteNonQuery();
            Obj.SqlConn.Close();
            strMsg = Obj.SqlCmd.Parameters["@strMsg"].Value.ToString();
            //DeleteRecordInUpdate(lblRoleID);
        }
        catch (SqlException ex)
        {
            MessageBox.Show(ex.ToString(), BLL.strCompanyName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }
        finally
        {
            Obj.SqlConn.Close();
        }
    }

    //-----------------Update Data into SQL Database---------------
    public static void UpdateFormDataDLL(TextBox txtEpmid, TextBox txtName, DateTimePicker dtpDob, TextBox txtSalary, ref string strMsg)
    {
        try
        {
            Obj.SqlConn = new SqlConnection(Obj.ConnectionString());
            Obj.SqlCmd = new SqlCommand("ProcUpdate_Emp_Detail", Obj.SqlConn);
            Obj.SqlCmd.CommandType = CommandType.StoredProcedure;
            Obj.SqlCmd.Parameters.Add("@ID", SqlDbType.Int).Value = Form1BLL.INTID;
            Obj.SqlCmd.Parameters.Add("@EmpId", SqlDbType.NVarChar, 100).Value = txtEpmid.Text.Trim();
            Obj.SqlCmd.Parameters.Add("@Name", SqlDbType.NVarChar, 100).Value = txtName.Text.Trim();
            Obj.SqlCmd.Parameters.Add("@DOB", SqlDbType.SmallDateTime).Value = dtpDob.Value.Date;
            Obj.SqlCmd.Parameters.Add("@Salary", SqlDbType.NVarChar, 100).Value = txtSalary.Text.Trim();


            Obj.SqlCmd.Parameters.Add("@strMsg", SqlDbType.NVarChar, 100).Direction = ParameterDirection.Output;
            Obj.SqlConn.Open();
            Obj.SqlCmd.ExecuteNonQuery();
            Obj.SqlConn.Close();
            strMsg = Obj.SqlCmd.Parameters["@strMsg"].Value.ToString();
            //DeleteRecordInUpdate(lblRoleID);
        }
        catch (SqlException ex)
        {
            MessageBox.Show(ex.ToString(), BLL.strCompanyName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }
        finally
        {
            Obj.SqlConn.Close();
        }
    }
}
