﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using GeneralFunction;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //DataTable dtTmp = new DataTable();
        //DataRow dr;
        //public void BindTable()
        //{
        //    dtTmp.Columns.Clear();
        //    dtTmp.Rows.Clear();
        //    dtTmp.Columns.Add("BOOKCODE");
        //    dtTmp.Columns.Add("Qty");
        //    dtTmp.Columns.Add("POID");
        //    dtTmp.Columns.Add("DATE");
        //}
    
        private void btnReport_Click(object sender, EventArgs e)
        {
            DataTable tmpp = BLL.obj.opnTable("ProcScanReprotvv'" + dtpFrom.Value.Date + "','" + dtpTo.Value.Date + "'");

            //DataTable tmpp = BLL.obj.opnTable("ProcScanReprotvv'" + dtpFrom.Value.Date + "' ,'" + dtpTo.Value.Date + "'");
            //if (tmpp.Rows.Count < 0)
            //{
            //    DataRow dr;
            //    foreach (DataRow item in tmpp.Rows)
            //    {
            //        dr = tmpp.NewRow();
            //        dr["BOOKCODE"] = item["TID"].ToString();
            //        dr["Qty"] = item["Qty"].ToString();
            //        dr["POID"] = item["POID"].ToString();
            //        dr["DATE"] = item["CreatedDate"].ToString();
            //        tmpp.Rows.Add(dr);
            //    }

                //BLL.obj.ExportDataToExcel(tmpp, "Report");
            //}
            BLL.obj.ExportDataToExcel(tmpp, "Scan_Report");
        }
    }
}

