﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblScan_report = new System.Windows.Forms.Label();
            this.lblBookcode = new System.Windows.Forms.Label();
            this.lblPoid = new System.Windows.Forms.Label();
            this.btnReport = new System.Windows.Forms.Button();
            this.dtpFrom = new System.Windows.Forms.DateTimePicker();
            this.dtpTo = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // lblScan_report
            // 
            this.lblScan_report.AutoSize = true;
            this.lblScan_report.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblScan_report.Location = new System.Drawing.Point(177, 9);
            this.lblScan_report.Name = "lblScan_report";
            this.lblScan_report.Size = new System.Drawing.Size(134, 20);
            this.lblScan_report.TabIndex = 0;
            this.lblScan_report.Text = "SCAN REPORT";
            this.lblScan_report.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblBookcode
            // 
            this.lblBookcode.AutoSize = true;
            this.lblBookcode.Location = new System.Drawing.Point(43, 53);
            this.lblBookcode.Name = "lblBookcode";
            this.lblBookcode.Size = new System.Drawing.Size(30, 13);
            this.lblBookcode.TabIndex = 1;
            this.lblBookcode.Text = "From";
            // 
            // lblPoid
            // 
            this.lblPoid.AutoSize = true;
            this.lblPoid.Location = new System.Drawing.Point(217, 53);
            this.lblPoid.Name = "lblPoid";
            this.lblPoid.Size = new System.Drawing.Size(20, 13);
            this.lblPoid.TabIndex = 2;
            this.lblPoid.Text = "To";
            // 
            // btnReport
            // 
            this.btnReport.Location = new System.Drawing.Point(181, 92);
            this.btnReport.Name = "btnReport";
            this.btnReport.Size = new System.Drawing.Size(75, 23);
            this.btnReport.TabIndex = 5;
            this.btnReport.Text = "Report";
            this.btnReport.UseVisualStyleBackColor = true;
            this.btnReport.Click += new System.EventHandler(this.btnReport_Click);
            // 
            // dtpFrom
            // 
            this.dtpFrom.CustomFormat = "dd/MM/yyyy";
            this.dtpFrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpFrom.Location = new System.Drawing.Point(89, 47);
            this.dtpFrom.Name = "dtpFrom";
            this.dtpFrom.Size = new System.Drawing.Size(112, 20);
            this.dtpFrom.TabIndex = 6;
            // 
            // dtpTo
            // 
            this.dtpTo.CustomFormat = "dd/MM/yyyy";
            this.dtpTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpTo.Location = new System.Drawing.Point(254, 47);
            this.dtpTo.Name = "dtpTo";
            this.dtpTo.Size = new System.Drawing.Size(121, 20);
            this.dtpTo.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(427, 122);
            this.Controls.Add(this.dtpTo);
            this.Controls.Add(this.dtpFrom);
            this.Controls.Add(this.btnReport);
            this.Controls.Add(this.lblPoid);
            this.Controls.Add(this.lblBookcode);
            this.Controls.Add(this.lblScan_report);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblScan_report;
        private System.Windows.Forms.Label lblBookcode;
        private System.Windows.Forms.Label lblPoid;
        private System.Windows.Forms.Button btnReport;
        private System.Windows.Forms.DateTimePicker dtpFrom;
        private System.Windows.Forms.DateTimePicker dtpTo;
    }
}

